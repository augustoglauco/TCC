# Regra de Workspace — Assistente Virtual Multimodal (TCC)

> Recomendação: ative esta regra como **Always On** nas configurações de
> regras do Antigravity, para que todo agente (Editor View ou Manager
> Surface) tenha este contexto sem precisar de `@mention` manual.

Este é um projeto de TCC: um assistente virtual multimodal (texto, imagem,
áudio) com um Roteador/Orquestrador baseado em LLM, RAG (texto e imagem) e
dois MCPs — um consumido (Google Calendar) e um provido pela empresa
(catálogo/estoque/preços + ferramentas B2B).

**Não duplique arquitetura ou escopo aqui.** Os documentos abaixo, na raiz
deste workspace, são a fonte de verdade — leia-os antes de propor ou
implementar qualquer mudança:

- `docs/ARCHITECTURE.md` — arquitetura completa, os 12 requisitos
  funcionais, escopo do MVP x evolução futura, riscos conhecidos.
- `docs/ROADMAP.md` — próxima tarefa a implementar e progresso atual
  (checklist por fase).
- `docs/CONVENTIONS.md` — stack (Python/FastAPI), estrutura de pastas,
  estilo de código, convenções de teste e git.
- `docs/EVALUATION.md` — como implementar a avaliação experimental
  (acerto do roteador, qualidade do RAG, latência local x externo).
- `docs/AGENTIC_WORKFLOW.md` — divisão de trabalho entre Antigravity e
  Claude Code CLI, loop de trabalho e boas práticas de revisão.
- `CLAUDE.md` — o mesmo contexto, na versão consumida pelo Claude Code CLI.

## Regras rápidas para qualquer agente neste workspace

1. Implemente apenas o que está descrito como MVP em `docs/ARCHITECTURE.md`
   e `docs/ROADMAP.md`. Itens em "Evolução futura" ou na lista "fora do MVP"
   não devem ser implementados sem decisão explícita do desenvolvedor.
2. Marque simplificações de escopo no código com `# MVP: <limitação>`.
3. Ao concluir uma tarefa, marque a caixa correspondente em
   `docs/ROADMAP.md` (`- [x]`).
4. Nunca gere ou insira credenciais/chaves de API reais — use variáveis de
   ambiente (`.env.example`).
5. Gere Artifacts (plano, screenshots, gravações) para qualquer tarefa
   executada no Manager Surface, para permitir revisão sem ler logs brutos.
6. Se uma tarefa exigir uma decisão de arquitetura não coberta nos
   documentos acima, pare e proponha a atualização de
   `docs/ARCHITECTURE.md` antes de prosseguir.
